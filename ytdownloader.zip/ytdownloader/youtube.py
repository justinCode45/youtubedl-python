
from PyQt5 import QtCore, QtGui, QtWidgets
import urllib.request as req
import youtube_dl as yt
from Ui_UIm import Ui_MainWindow
import sys
import os
from PyQt5.QtCore import QThread,pyqtSignal
import time



class hok :
    dic ={}
    def my_hook(d):
        hok.dic=d
        
    def get (ty):
        return hok.dic[ty]
    
def OPTS (fomat,path):
    #設定請求資料
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best',  
        'outtmpl': path+"/%(title)s.%(ext)s",        
        'noplaylist' : True, 
        "progress_hooks":[hok.my_hook],       
        'postprocessors': [{
            'key': 'FFmpegVideoConvertor',
            'preferedformat': fomat,  # one of avi, flv, mkv, mp4, ogg, webm
        }]
        
    }
    return ydl_opts


def IMG(info) :
    #解析縮圖
    with req.urlopen(info.get("thumbnail")) as web:
        data=web.read()
    #儲存縮圖
    with open("pic.jpg",mode="wb") as im :
        im.write(data)


def YTINFO(url,opts,bool=True):
    #用youtube dl讀取網頁
    try:
        with yt.YoutubeDL(opts) as ydl:
            info=ydl.extract_info(url,download=bool)
        return info
    except:
        return 4

#---------------------------------------------------------
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.Go_click)
        self.ui.mp4.toggled.connect(self.onClicked)
        self.ui.mp3.toggled.connect(self.onClicked)
        self.ui.cheak.clicked.connect(self.Cheak_click)
        self.work1 = DownThread()
        self.work2 = DisThread()
        self.work1.trigger.connect(self.display)
        self.work2.trigger.connect(self.dist)
        self.ui.cheak.setFont(QtGui.QFont("Times", 12, QtGui.QFont.Bold))
        self.ui.ghg.setFont(QtGui.QFont("Times", 20, QtGui.QFont.Bold))
        self.ui.pushButton.setFont(QtGui.QFont("Times", 12, QtGui.QFont.Bold))
       
        
        
        



    global Cotrl
    Cotrl=1

    def Cheak_click (self): 
        try:
            url=self.ui.net.text()
            info=YTINFO(str(url),None,False)  
            IMG(info)
            self.ui.label_4.setScaledContents(True) 
            self.ui.label_4.setPixmap(QtGui.QPixmap("pic.jpg"))
            os.remove("pic.jpg")
        except:
            QtWidgets.QMessageBox.warning(self,'警告','網址錯誤')
            self.ui.net.setText(None)
        
        
    def Go_click (self):
        try :
            hok.dic.clear()
            self.Cotrl=1
            self.work1.foms=k
            self.work1.url=self.ui.net.text()
            self.work1.path=str(QtWidgets.QFileDialog.getExistingDirectory(self,"choose directory","C:") )
            self.work1.start()
            self.ui.pushButton.setEnabled(False)
            self.work2.start()
        except:
            QtWidgets.QMessageBox.warning(self,'警告','請選擇輸出格式')
            self.Cotrl=0
            self.ui.pushButton.setEnabled(True)



    def onClicked(self):
        radioBtn = self.sender()
        if radioBtn.isChecked():
            global k 
            k =  radioBtn.text()

    def display(self,bool):
        if  bool==4 :
            QtWidgets.QMessageBox.warning(self,'警告','網址錯誤')
            self.ui.pushButton.setEnabled(True)
            self.ui.net.setText(None)
            self.Cotrl=0
            
    def dist(self,word,bool,val):
        self.ui.ghg.setText(word)
        self.ui.progressBar.setValue(int(float(val.strip().strip("%"))))
        if bool :
            self.ui.label_4.setText("")
            self.ui.net.setText("")
            self.ui.pushButton.setEnabled(True)
            self.ui.mp3.setChecked(False)
            self.ui.mp3.setChecked(False)
            hok.dic.clear()
       
      
class DisThread(QThread):
    #多執行緒  讓下載時不會當機
    def __init__(self):
        super(DisThread,self).__init__() 

    trigger=pyqtSignal(str,bool,str)
    

    def run(self):  
        try:
            while hok.get("status")=="downloading":
                self.trigger.emit(hok.get("status")+"\n"+hok.get("_eta_str"),False,hok.get("_percent_str"))
                time.sleep(0.2)
            if hok.get("status") =="finished":
                time.sleep(5)
                self.trigger.emit(hok.get("status"),True,"100") 
                

        except:
            if   Cotrl ==1 :
                time.sleep(0.2)
                self.run()


class DownThread(QThread):
    #多執行緒  讓下載時不會當機
    def __init__(self):
        super(DownThread,self).__init__() 

    trigger =pyqtSignal(int)
    url=str
    foms=str
    path=str
    def run(self):  
        bool=YTINFO(str(self.url),OPTS(str(self.foms),self.path))
        self.trigger.emit(bool) 
        

if __name__ == '__main__':
    app = QtWidgets.QApplication([])
    app_icon = QtGui.QIcon()
    app_icon.addFile('Youtube.ico', QtCore.QSize(512,512))
    app.setWindowIcon(app_icon)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
